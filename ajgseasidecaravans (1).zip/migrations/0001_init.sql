-- Initial schema for AJG Seaside Caravans (Cloudflare D1)
-- Mirrors prisma/schema.prisma — keep both in sync if you change one.

CREATE TABLE IF NOT EXISTS "Property" (
  "id" INTEGER PRIMARY KEY AUTOINCREMENT,
  "name" TEXT NOT NULL,
  "slug" TEXT NOT NULL UNIQUE,
  "tagline" TEXT,
  "description" TEXT,
  "location" TEXT,
  "sleeps" INTEGER NOT NULL DEFAULT 4,
  "bedrooms" INTEGER NOT NULL DEFAULT 2,
  "nightlyRate" INTEGER NOT NULL DEFAULT 9500,
  "cleaningFee" INTEGER NOT NULL DEFAULT 0,
  "currency" TEXT NOT NULL DEFAULT 'gbp',
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "Image" (
  "id" INTEGER PRIMARY KEY AUTOINCREMENT,
  "propertyId" INTEGER NOT NULL REFERENCES "Property"("id"),
  "url" TEXT NOT NULL,
  "key" TEXT,
  "alt" TEXT,
  "order" INTEGER NOT NULL DEFAULT 0,
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "Booking" (
  "id" INTEGER PRIMARY KEY AUTOINCREMENT,
  "propertyId" INTEGER NOT NULL REFERENCES "Property"("id"),
  "startDate" DATETIME NOT NULL,
  "endDate" DATETIME NOT NULL,
  "guestName" TEXT NOT NULL,
  "guestEmail" TEXT NOT NULL,
  "guests" INTEGER NOT NULL DEFAULT 2,
  "totalAmount" INTEGER NOT NULL,
  "currency" TEXT NOT NULL DEFAULT 'gbp',
  "stripeSessionId" TEXT UNIQUE,
  "status" TEXT NOT NULL DEFAULT 'PENDING',
  "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS "Image_propertyId_idx" ON "Image"("propertyId");
CREATE INDEX IF NOT EXISTS "Booking_propertyId_idx" ON "Booking"("propertyId");
CREATE INDEX IF NOT EXISTS "Booking_status_idx" ON "Booking"("status");
