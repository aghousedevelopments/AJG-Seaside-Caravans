-- Sample property so the site has something to show/book out of the box.
-- Edit these values (or update via SQL/Prisma Studio) to match the real caravan.
INSERT INTO "Property" ("id", "name", "slug", "tagline", "description", "location", "sleeps", "bedrooms", "nightlyRate", "cleaningFee", "currency")
VALUES (
  1,
  'AJG Seaside Caravans',
  'ajg-seaside-caravan',
  'Wake up to sea air and dune grass',
  'A cosy static caravan a short walk from the beach, with a private deck, full kitchen, and everything you need for a relaxed seaside break.',
  'Seaside, UK',
  6,
  3,
  9500,
  4000,
  'gbp'
)
ON CONFLICT("id") DO NOTHING;
