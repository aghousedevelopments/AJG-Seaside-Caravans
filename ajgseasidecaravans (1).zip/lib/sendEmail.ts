import type { Env } from "./env";

// Uses SendGrid's HTTP API directly via fetch (no Node SDK) so it runs on
// the Cloudflare edge runtime. Silently skips if no API key is configured.
export default async function sendEmail(
  env: Env,
  { to, subject, text, html }: { to: string; subject: string; text?: string; html?: string }
) {
  const apiKey = env.SENDGRID_API_KEY;
  if (!apiKey) {
    console.warn("SENDGRID_API_KEY not set — skipping email send");
    return;
  }
  const from = env.SENDGRID_FROM || `no-reply@${(env.NEXT_PUBLIC_SITE_URL || "localhost").replace(/^https?:\/\//, "")}`;

  const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      personalizations: [{ to: [{ email: to }] }],
      from: { email: from },
      subject,
      content: [
        { type: "text/plain", value: text || "" },
        ...(html ? [{ type: "text/html", value: html }] : []),
      ],
    }),
  });

  if (!res.ok) {
    console.error("Error sending email", res.status, await res.text());
  }
}
