export function formatMoney(minorUnits: number, currency: string) {
  return new Intl.NumberFormat("en-GB", { style: "currency", currency: currency.toUpperCase() }).format(minorUnits / 100);
}
