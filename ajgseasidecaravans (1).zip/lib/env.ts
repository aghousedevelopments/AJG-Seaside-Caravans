import { getCloudflareContext } from "@opennextjs/cloudflare";

export interface Env {
  DB: D1Database;
  GALLERY_BUCKET: R2Bucket;
  NEXT_PUBLIC_SITE_URL?: string;
  STRIPE_SECRET_KEY?: string;
  STRIPE_WEBHOOK_SECRET?: string;
  ADMIN_PASSWORD?: string;
  SENDGRID_API_KEY?: string;
  SENDGRID_FROM?: string;
}

// In production (and in `next dev` once initOpenNextCloudflareForDev() has
// run — see next.config.js) Cloudflare bindings are available via
// getCloudflareContext().
export function getEnv(): Env {
  const { env } = getCloudflareContext();
  return env as unknown as Env;
}
