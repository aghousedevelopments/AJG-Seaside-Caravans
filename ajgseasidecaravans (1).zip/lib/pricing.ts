export function nightsBetween(start: Date, end: Date) {
  const ms = end.getTime() - start.getTime();
  return Math.round(ms / (1000 * 60 * 60 * 24));
}

export function computeTotal(nightlyRate: number, cleaningFee: number, nights: number) {
  return nightlyRate * nights + cleaningFee;
}
