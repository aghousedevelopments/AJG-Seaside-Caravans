import { PrismaClient } from "@prisma/client";
import { PrismaD1 } from "@prisma/adapter-d1";
import type { Env } from "./env";

// D1 bindings are only available inside a request, so unlike a typical
// Prisma singleton we build a fresh (cheap) client per-request from the
// binding on `env`. The underlying D1 connection itself is pooled by the
// platform, so this is not a real per-request connection cost.
export function getPrisma(env: Env) {
  const adapter = new PrismaD1(env.DB);
  return new PrismaClient({ adapter });
}
