import type { Env } from "./env";

// Gallery images are stored as objects in the GALLERY_BUCKET R2 bucket and
// served back through /api/images/[key] (see that route) so no public R2
// domain or custom domain setup is required to get started.

function extensionFromMime(mime: string) {
  if (mime === "image/png") return "png";
  if (mime === "image/webp") return "webp";
  if (mime === "image/gif") return "gif";
  return "jpg";
}

export async function saveImage(env: Env, { dataUrl, filename }: { dataUrl: string; filename: string }) {
  const match = dataUrl.match(/^data:(.+);base64,(.*)$/);
  if (!match) throw new Error("Invalid data URL");
  const mime = match[1];
  const base64 = match[2];

  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);

  const ext = extensionFromMime(mime);
  const key = `gallery/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;

  await env.GALLERY_BUCKET.put(key, bytes, {
    httpMetadata: { contentType: mime },
  });

  const siteUrl = (env.NEXT_PUBLIC_SITE_URL || "").replace(/\/$/, "");
  const url = `${siteUrl}/api/images/${encodeURIComponent(key)}`;
  return { url, key };
}

export async function deleteImage(env: Env, key: string | null | undefined) {
  if (!key) return;
  try {
    await env.GALLERY_BUCKET.delete(key);
  } catch (err) {
    console.warn("deleteImage error", err);
  }
}
