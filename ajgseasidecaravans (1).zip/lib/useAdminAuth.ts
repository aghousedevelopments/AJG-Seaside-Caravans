import { useEffect, useState, useCallback } from "react";

// Client-side helper for the admin pages: keeps the Basic Auth password in
// sessionStorage, verifies it against a lightweight endpoint, and hands back
// an `authHeader()` to attach to admin API calls.
export function useAdminAuth() {
  const [password, setPassword] = useState("");
  const [authorized, setAuthorized] = useState(false);
  const [checked, setChecked] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const verify = useCallback(async (pw: string) => {
    setError(null);
    const res = await fetch("/api/admin/property?propertyId=1", {
      headers: { Authorization: "Basic " + btoa(`admin:${pw}`) },
    });
    if (res.ok) {
      setAuthorized(true);
      setPassword(pw);
      sessionStorage.setItem("adminPassword", pw);
    } else {
      setAuthorized(false);
      setError("Incorrect password");
      sessionStorage.removeItem("adminPassword");
    }
    setChecked(true);
    return res.ok;
  }, []);

  useEffect(() => {
    const saved = sessionStorage.getItem("adminPassword");
    if (saved) verify(saved);
    else setChecked(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const authHeader = useCallback(() => ({ Authorization: "Basic " + btoa(`admin:${password}`) }), [password]);

  function logout() {
    sessionStorage.removeItem("adminPassword");
    setAuthorized(false);
    setPassword("");
  }

  return { authorized, checked, error, verify, authHeader, logout };
}
