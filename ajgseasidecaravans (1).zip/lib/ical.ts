// Minimal, dependency-free ICS generator (edge-runtime safe).
function toIcsDate(d: Date) {
  return d.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
}

function escapeText(s: string) {
  return s.replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\n/g, "\\n");
}

export function buildIcs(
  domain: string,
  events: { id: number | string; start: Date; end: Date; summary: string; description?: string }[]
) {
  const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//" + domain + "//Bookings//EN", "CALSCALE:GREGORIAN"];
  const now = toIcsDate(new Date());
  for (const ev of events) {
    lines.push(
      "BEGIN:VEVENT",
      `UID:${ev.id}@${domain}`,
      `DTSTAMP:${now}`,
      `DTSTART:${toIcsDate(ev.start)}`,
      `DTEND:${toIcsDate(ev.end)}`,
      `SUMMARY:${escapeText(ev.summary)}`,
      ...(ev.description ? [`DESCRIPTION:${escapeText(ev.description)}`] : []),
      "END:VEVENT"
    );
  }
  lines.push("END:VCALENDAR");
  return lines.join("\r\n");
}
