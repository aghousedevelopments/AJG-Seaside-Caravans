import type { NextApiRequest, NextApiResponse } from "next";

// Shared HTTP Basic Auth check for /api/admin/* routes.
// Username is always "admin"; password is the ADMIN_PASSWORD secret.
export function checkAdminAuth(req: NextApiRequest, adminPassword: string | undefined): boolean {
  if (!adminPassword) return false;
  const header = req.headers.authorization;
  if (!header || !header.startsWith("Basic ")) return false;
  try {
    const decoded = Buffer.from(header.slice(6), "base64").toString("utf8");
    const idx = decoded.indexOf(":");
    if (idx === -1) return false;
    const user = decoded.slice(0, idx);
    const pass = decoded.slice(idx + 1);
    return user === "admin" && pass === adminPassword;
  } catch {
    return false;
  }
}

export function sendUnauthorized(res: NextApiResponse) {
  res.setHeader("WWW-Authenticate", 'Basic realm="Admin"');
  res.status(401).json({ error: "unauthorized" });
}
