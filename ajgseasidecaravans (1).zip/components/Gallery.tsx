import { useState } from "react";
import Image from "next/image";

export type GalleryImage = { id?: number; url: string; alt?: string | null };

export default function Gallery({ images }: { images: GalleryImage[] }) {
  const [active, setActive] = useState<number | null>(null);

  if (!images.length) {
    return <p className="text-sage-500">Photos coming soon.</p>;
  }

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {images.map((img, i) => (
          <button
            key={img.id ?? i}
            type="button"
            onClick={() => setActive(i)}
            className="relative w-full h-40 md:h-52 overflow-hidden rounded-lg group focus:outline-none focus:ring-2 focus:ring-sage-400"
          >
            <Image
              src={img.url}
              alt={img.alt ?? `Photo ${i + 1}`}
              fill
              unoptimized
              className="object-cover transition-transform duration-300 group-hover:scale-105"
            />
          </button>
        ))}
      </div>

      {active !== null && (
        <div
          className="fixed inset-0 z-50 bg-sage-950/90 flex items-center justify-center p-4"
          onClick={() => setActive(null)}
        >
          <div className="relative w-full max-w-3xl h-[70vh]">
            <Image src={images[active].url} alt={images[active].alt ?? ""} fill unoptimized className="object-contain" />
          </div>
          <button
            className="absolute top-4 right-4 text-white text-2xl leading-none"
            onClick={() => setActive(null)}
            aria-label="Close"
          >
            ×
          </button>
        </div>
      )}
    </>
  );
}
