import { useEffect, useMemo, useState } from "react";
import { DayPicker, DateRange } from "react-day-picker";
import { differenceInCalendarDays, isWithinInterval } from "date-fns";
import { formatMoney } from "../lib/format";

type Property = {
  id: number;
  name: string;
  nightlyRate: number;
  cleaningFee: number;
  currency: string;
};

type BookedRange = { start: string; end: string };

export default function BookingWidget({ propertyId = 1 }: { propertyId?: number }) {
  const [property, setProperty] = useState<Property | null>(null);
  const [booked, setBooked] = useState<BookedRange[]>([]);
  const [range, setRange] = useState<DateRange | undefined>();
  const [guestName, setGuestName] = useState("");
  const [guestEmail, setGuestEmail] = useState("");
  const [guests, setGuests] = useState(2);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    fetch(`/api/property?propertyId=${propertyId}`).then((r) => r.json()).then((d: any) => d.property && setProperty(d.property));
    fetch(`/api/availability?propertyId=${propertyId}`).then((r) => r.json()).then((d: any) => setBooked(d.ranges || []));
  }, [propertyId]);

  const disabledDates = useMemo(() => {
    const ranges = booked.map((b) => ({ from: new Date(b.start), to: new Date(new Date(b.end).getTime() - 1) }));
    return [{ before: new Date(new Date().setHours(0, 0, 0, 0)) }, ...ranges];
  }, [booked]);

  const nights = range?.from && range?.to ? differenceInCalendarDays(range.to, range.from) : 0;
  const total = property && nights > 0 ? property.nightlyRate * nights + property.cleaningFee : 0;

  function rangeOverlapsBooked(from: Date, to: Date) {
    return booked.some((b) => from < new Date(b.end) && to > new Date(b.start));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setMessage(null);
    if (!range?.from || !range?.to || nights <= 0) return setMessage("Choose your check-in and check-out dates.");
    if (rangeOverlapsBooked(range.from, range.to)) return setMessage("Those dates include an unavailable night — please pick again.");
    if (!guestName || !guestEmail) return setMessage("Please fill in your name and email.");

    setLoading(true);
    const res = await fetch("/api/book", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        propertyId,
        startDate: range.from.toISOString(),
        endDate: range.to.toISOString(),
        guestName,
        guestEmail,
        guests,
      }),
    });
    const json: any = await res.json();
    setLoading(false);
    if (json.url) window.location.href = json.url;
    else setMessage(json.error || "Something went wrong — please try again.");
  }

  return (
    <div className="grid md:grid-cols-2 gap-8 items-start">
      <div className="card p-4">
        <DayPicker
          mode="range"
          numberOfMonths={1}
          selected={range}
          onSelect={setRange}
          disabled={disabledDates}
          fromMonth={new Date()}
          className="rdp-sage"
        />
        <p className="text-xs text-sage-500 px-2 pb-1">Greyed-out dates are already booked.</p>
      </div>

      <form onSubmit={submit} className="card p-6 space-y-4">
        <div>
          <p className="text-sm text-sage-600">
            {range?.from && range?.to
              ? `${range.from.toDateString()} → ${range.to.toDateString()} (${nights} night${nights === 1 ? "" : "s"})`
              : "Select your dates on the calendar"}
          </p>
          {property && nights > 0 && (
            <div className="mt-2 text-sm text-sage-800 space-y-0.5">
              <div className="flex justify-between">
                <span>{formatMoney(property.nightlyRate, property.currency)} × {nights} night{nights === 1 ? "" : "s"}</span>
                <span>{formatMoney(property.nightlyRate * nights, property.currency)}</span>
              </div>
              {property.cleaningFee > 0 && (
                <div className="flex justify-between">
                  <span>Cleaning fee</span>
                  <span>{formatMoney(property.cleaningFee, property.currency)}</span>
                </div>
              )}
              <div className="flex justify-between font-semibold text-base border-t border-sage-100 pt-1 mt-1">
                <span>Total</span>
                <span>{formatMoney(total, property.currency)}</span>
              </div>
            </div>
          )}
        </div>

        <div>
          <label className="label">Full name</label>
          <input className="input" value={guestName} onChange={(e) => setGuestName(e.target.value)} required />
        </div>
        <div>
          <label className="label">Email</label>
          <input type="email" className="input" value={guestEmail} onChange={(e) => setGuestEmail(e.target.value)} required />
        </div>
        <div>
          <label className="label">Guests</label>
          <input type="number" min={1} className="input" value={guests} onChange={(e) => setGuests(Number(e.target.value))} />
        </div>

        <button className="btn-accent w-full" disabled={loading}>
          {loading ? "Redirecting to payment…" : "Reserve & pay"}
        </button>
        {message && <p className="text-accent-600 text-sm">{message}</p>}
        <p className="text-xs text-sage-500">You'll be securely redirected to Stripe to complete payment.</p>
      </form>
    </div>
  );
}
