import { useState } from "react";
import { useAdminAuth } from "../lib/useAdminAuth";

export default function AdminGate({ children }: { children: (auth: { authHeader: () => Record<string, string>; logout: () => void }) => React.ReactNode }) {
  const { authorized, checked, error, verify, authHeader, logout } = useAdminAuth();
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  if (!checked) {
    return <div className="section py-16 text-sage-500">Checking access…</div>;
  }

  if (!authorized) {
    return (
      <div className="section py-16 max-w-sm">
        <div className="card p-6">
          <h1 className="text-xl font-bold mb-1">Admin sign in</h1>
          <p className="text-sm text-sage-600 mb-4">Enter the admin password to continue.</p>
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setLoading(true);
              await verify(input);
              setLoading(false);
            }}
            className="space-y-3"
          >
            <input
              type="password"
              className="input"
              placeholder="Admin password"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              autoFocus
            />
            <button className="btn-primary w-full" disabled={loading}>
              {loading ? "Checking…" : "Sign in"}
            </button>
            {error && <p className="text-accent-600 text-sm">{error}</p>}
          </form>
        </div>
      </div>
    );
  }

  return <>{children({ authHeader, logout })}</>;
}
