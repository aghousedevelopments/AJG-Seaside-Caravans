import Link from "next/link";
import { ReactNode } from "react";

export default function Layout({ children, propertyName = "AJG Seaside Caravans" }: { children: ReactNode; propertyName?: string }) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-sage-100 bg-shell-50/90 backdrop-blur sticky top-0 z-30">
        <div className="section flex items-center justify-between py-4">
          <Link href="/" className="flex items-center gap-2 font-display text-lg font-bold text-sage-800">
            <span className="inline-block w-3 h-3 rounded-full bg-accent-500" aria-hidden />
            {propertyName}
          </Link>
          <nav className="flex items-center gap-5 text-sm font-medium text-sage-700">
            <Link href="/#gallery" className="hover:text-sage-900">Gallery</Link>
            <Link href="/#about" className="hover:text-sage-900">About</Link>
            <Link href="/#book" className="btn-accent !px-4 !py-2 text-sm">Book now</Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <footer className="bg-sage-900 text-sage-100 mt-16">
        <div className="section py-10 grid gap-6 md:grid-cols-3 text-sm">
          <div>
            <p className="font-display text-lg text-white mb-2">{propertyName}</p>
            <p className="text-sage-300">A relaxed seaside caravan break, booked in minutes.</p>
          </div>
          <div>
            <p className="font-semibold text-white mb-2">Explore</p>
            <ul className="space-y-1 text-sage-300">
              <li><Link href="/#gallery" className="hover:text-white">Gallery</Link></li>
              <li><Link href="/#book" className="hover:text-white">Availability &amp; booking</Link></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold text-white mb-2">Owners</p>
            <ul className="space-y-1 text-sage-300">
              <li><Link href="/admin" className="hover:text-white">Admin</Link></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-sage-800 py-4 text-center text-xs text-sage-400">
          © {new Date().getFullYear()} {propertyName}
        </div>
      </footer>
    </div>
  );
}
