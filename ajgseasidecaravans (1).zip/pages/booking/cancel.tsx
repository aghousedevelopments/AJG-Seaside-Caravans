import Link from "next/link";
import Layout from "../../components/Layout";

export default function BookingCancel() {
  return (
    <Layout>
      <div className="section py-20 max-w-lg">
        <div className="card p-8">
          <h1 className="text-2xl font-bold mb-3">Booking not completed</h1>
          <p className="text-sage-700">Your payment was cancelled or didn't go through, so no charge was made.</p>
          <Link href="/booking" className="btn-primary mt-6 inline-flex">Try again</Link>
        </div>
      </div>
    </Layout>
  );
}
