import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Layout from "../../components/Layout";
import { formatMoney } from "../../lib/format";

type Booking = {
  id: number;
  guestName: string;
  guestEmail: string;
  startDate: string;
  endDate: string;
  totalAmount: number;
  currency: string;
  status: string;
};

export default function BookingSuccess() {
  const router = useRouter();
  const { session_id } = router.query;
  const [booking, setBooking] = useState<Booking | null | undefined>(undefined);

  useEffect(() => {
    if (!session_id || typeof session_id !== "string") return;
    fetch(`/api/booking-status?session_id=${encodeURIComponent(session_id)}`)
      .then((r) => r.json())
      .then((d: any) => setBooking(d.booking ?? null));
  }, [session_id]);

  return (
    <Layout>
      <div className="section py-20 max-w-lg">
        {booking === undefined && <p className="text-sage-500">Loading your booking…</p>}
        {booking === null && <p>We couldn't find that booking.</p>}
        {booking && (
          <div className="card p-8">
            <span className="inline-block bg-sage-100 text-sage-700 text-xs font-semibold px-3 py-1 rounded-full mb-4">
              {booking.status}
            </span>
            <h1 className="text-2xl font-bold mb-4">Thanks, {booking.guestName.split(" ")[0]}!</h1>
            <p className="text-sage-700">
              Your booking <strong>#{booking.id}</strong> for{" "}
              <strong>{new Date(booking.startDate).toDateString()}</strong> to{" "}
              <strong>{new Date(booking.endDate).toDateString()}</strong> is confirmed.
            </p>
            <p className="mt-2 text-sage-700">Total paid: {formatMoney(booking.totalAmount, booking.currency)}</p>
            <p className="mt-4 text-sm text-sage-500">
              A confirmation email is on its way to {booking.guestEmail}. If the status above still shows PENDING,
              refresh in a few seconds — it updates as soon as payment is confirmed.
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
}
