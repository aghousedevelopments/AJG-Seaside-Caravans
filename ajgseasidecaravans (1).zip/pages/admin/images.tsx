import { useEffect, useState } from "react";
import Link from "next/link";
import AdminGate from "../../components/AdminGate";

type Img = { id: number; url: string; alt: string | null; order: number };

function ImagesEditor({ authHeader }: { authHeader: () => Record<string, string> }) {
  const propertyId = 1;
  const [images, setImages] = useState<Img[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [alt, setAlt] = useState("");
  const [loading, setLoading] = useState(false);

  async function fetchImages() {
    const res = await fetch(`/api/admin/images?propertyId=${propertyId}`, { headers: authHeader() });
    const json: any = await res.json();
    setImages(json.images || []);
  }

  useEffect(() => {
    fetchImages();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function upload(e: React.FormEvent) {
    e.preventDefault();
    if (!file) return alert("Choose a file");
    setLoading(true);
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      const res = await fetch("/api/admin/images", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeader() },
        body: JSON.stringify({ propertyId, filename: file.name, dataUrl, alt, order: images.length }),
      });
      const json: any = await res.json();
      setLoading(false);
      if (json.error) return alert(json.error);
      setFile(null);
      setAlt("");
      fetchImages();
    };
    reader.readAsDataURL(file);
  }

  async function remove(id: number) {
    if (!confirm("Delete this photo?")) return;
    const res = await fetch("/api/admin/delete-image", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({ id }),
    });
    const json: any = await res.json();
    if (json.ok) fetchImages();
    else alert(json.error || "delete failed");
  }

  async function move(index: number, dir: -1 | 1) {
    const next = [...images];
    const swapWith = index + dir;
    if (swapWith < 0 || swapWith >= next.length) return;
    [next[index], next[swapWith]] = [next[swapWith], next[index]];
    setImages(next);
    await fetch("/api/admin/reorder-images", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({ order: next.map((i) => i.id) }),
    });
  }

  return (
    <div className="space-y-8">
      <form onSubmit={upload} className="card p-6 space-y-3 max-w-md">
        <h2 className="font-semibold">Add a photo</h2>
        <input type="file" accept="image/*" onChange={(e) => setFile(e.target.files ? e.target.files[0] : null)} />
        <input placeholder="Alt text / caption (optional)" value={alt} onChange={(e) => setAlt(e.target.value)} className="input" />
        <button className="btn-primary" disabled={loading}>{loading ? "Uploading…" : "Upload"}</button>
      </form>

      <div>
        <h2 className="font-semibold mb-3">Photos ({images.length})</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {images.map((img, i) => (
            <div key={img.id} className="card p-2">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={img.url} alt={img.alt || ""} className="w-full h-32 object-cover rounded" />
              <p className="text-xs mt-1 truncate">{img.alt || <span className="text-sage-400">No caption</span>}</p>
              <div className="mt-2 flex items-center justify-between gap-1">
                <div className="flex gap-1">
                  <button className="btn-outline !px-2 !py-1 text-xs" onClick={() => move(i, -1)} disabled={i === 0}>↑</button>
                  <button className="btn-outline !px-2 !py-1 text-xs" onClick={() => move(i, 1)} disabled={i === images.length - 1}>↓</button>
                </div>
                <button className="btn-accent !px-2 !py-1 text-xs" onClick={() => remove(img.id)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function AdminImages() {
  return (
    <div className="min-h-screen bg-shell-50">
      <div className="section py-10">
        <Link href="/admin" className="text-sm text-sage-500 hover:text-sage-800">← Admin</Link>
        <h1 className="text-2xl font-bold mt-2 mb-6">Gallery</h1>
        <AdminGate>{({ authHeader }) => <ImagesEditor authHeader={authHeader} />}</AdminGate>
      </div>
    </div>
  );
}
