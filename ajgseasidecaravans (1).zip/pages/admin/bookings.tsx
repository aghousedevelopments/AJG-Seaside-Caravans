import { useEffect, useState } from "react";
import Link from "next/link";
import AdminGate from "../../components/AdminGate";
import { formatMoney } from "../../lib/format";

type Booking = {
  id: number;
  property?: { name: string };
  guestName: string;
  guestEmail: string;
  startDate: string;
  endDate: string;
  totalAmount: number;
  currency: string;
  status: string;
};

function BookingsTable({ authHeader }: { authHeader: () => Record<string, string> }) {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  async function fetchBookings() {
    setLoading(true);
    const res = await fetch("/api/admin/bookings", { headers: authHeader() });
    const json: any = await res.json();
    setBookings(json.bookings || []);
    setLoading(false);
  }

  useEffect(() => {
    fetchBookings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function setStatus(id: number, status: string) {
    await fetch("/api/admin/update-booking", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({ id, status }),
    });
    fetchBookings();
  }

  if (loading) return <p className="text-sage-500">Loading…</p>;
  if (!bookings.length) return <p className="text-sage-500">No bookings yet.</p>;

  return (
    <div className="overflow-x-auto card">
      <table className="w-full text-sm">
        <thead className="bg-sage-50 text-left">
          <tr>
            <th className="p-3">ID</th>
            <th className="p-3">Guest</th>
            <th className="p-3">Dates</th>
            <th className="p-3">Amount</th>
            <th className="p-3">Status</th>
            <th className="p-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          {bookings.map((b) => (
            <tr key={b.id} className="border-t border-sage-100">
              <td className="p-3">{b.id}</td>
              <td className="p-3">
                {b.guestName}
                <br />
                <span className="text-xs text-sage-500">{b.guestEmail}</span>
              </td>
              <td className="p-3">
                {new Date(b.startDate).toDateString()} — {new Date(b.endDate).toDateString()}
              </td>
              <td className="p-3">{formatMoney(b.totalAmount, b.currency)}</td>
              <td className="p-3">
                <span
                  className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                    b.status === "CONFIRMED"
                      ? "bg-sage-100 text-sage-700"
                      : b.status === "CANCELLED"
                      ? "bg-accent-100 text-accent-700"
                      : "bg-shell-200 text-sage-700"
                  }`}
                >
                  {b.status}
                </span>
              </td>
              <td className="p-3 space-x-2">
                <button className="btn-primary !px-2 !py-1 text-xs" onClick={() => setStatus(b.id, "CONFIRMED")}>
                  Confirm
                </button>
                <button className="btn-accent !px-2 !py-1 text-xs" onClick={() => setStatus(b.id, "CANCELLED")}>
                  Cancel
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function AdminBookings() {
  return (
    <div className="min-h-screen bg-shell-50">
      <div className="section py-10">
        <Link href="/admin" className="text-sm text-sage-500 hover:text-sage-800">← Admin</Link>
        <h1 className="text-2xl font-bold mt-2 mb-6">Bookings</h1>
        <AdminGate>{({ authHeader }) => <BookingsTable authHeader={authHeader} />}</AdminGate>
      </div>
    </div>
  );
}
