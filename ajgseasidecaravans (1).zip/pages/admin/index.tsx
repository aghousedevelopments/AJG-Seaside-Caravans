import Link from "next/link";
import AdminGate from "../../components/AdminGate";

export default function AdminHome() {
  return (
    <div className="min-h-screen bg-shell-50">
      <div className="section py-10">
        <h1 className="text-2xl font-bold mb-6">Admin</h1>
        <AdminGate>
          {({ logout }) => (
            <div className="space-y-4">
              <div className="grid sm:grid-cols-3 gap-4">
                <Link href="/admin/images" className="card p-6 hover:shadow-lg transition-shadow">
                  <h2 className="font-semibold mb-1">Gallery</h2>
                  <p className="text-sm text-sage-600">Upload, caption, reorder and delete photos.</p>
                </Link>
                <Link href="/admin/bookings" className="card p-6 hover:shadow-lg transition-shadow">
                  <h2 className="font-semibold mb-1">Bookings</h2>
                  <p className="text-sm text-sage-600">View and manage guest bookings.</p>
                </Link>
                <Link href="/admin/property" className="card p-6 hover:shadow-lg transition-shadow">
                  <h2 className="font-semibold mb-1">Listing details</h2>
                  <p className="text-sm text-sage-600">Edit the name, description and nightly rate.</p>
                </Link>
              </div>
              <button className="btn-outline" onClick={logout}>Sign out</button>
            </div>
          )}
        </AdminGate>
      </div>
    </div>
  );
}
