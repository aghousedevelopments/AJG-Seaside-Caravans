import { useEffect, useState } from "react";
import Link from "next/link";
import AdminGate from "../../components/AdminGate";

type Property = {
  id: number;
  name: string;
  tagline: string | null;
  description: string | null;
  location: string | null;
  sleeps: number;
  bedrooms: number;
  nightlyRate: number;
  cleaningFee: number;
  currency: string;
};

function PropertyEditor({ authHeader }: { authHeader: () => Record<string, string> }) {
  const propertyId = 1;
  const [property, setProperty] = useState<Property | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch(`/api/admin/property?propertyId=${propertyId}`, { headers: authHeader() })
      .then((r) => r.json())
      .then((d: any) => setProperty(d.property));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!property) return <p className="text-sage-500">Loading…</p>;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setSaved(false);
    const res = await fetch("/api/admin/property", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify({ propertyId, ...property }),
    });
    const json: any = await res.json();
    setSaving(false);
    if (json.property) {
      setProperty(json.property);
      setSaved(true);
    }
  }

  function field<K extends keyof Property>(key: K) {
    return {
      value: property![key] ?? "",
      onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
        setProperty({ ...property!, [key]: e.target.value } as Property),
    };
  }

  return (
    <form onSubmit={save} className="card p-6 max-w-xl space-y-4">
      <div>
        <label className="label">Name</label>
        <input className="input" {...field("name")} />
      </div>
      <div>
        <label className="label">Tagline</label>
        <input className="input" {...field("tagline")} />
      </div>
      <div>
        <label className="label">Description</label>
        <textarea className="input" rows={4} {...field("description")} />
      </div>
      <div>
        <label className="label">Location</label>
        <input className="input" {...field("location")} />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="label">Sleeps</label>
          <input type="number" className="input" {...field("sleeps")} />
        </div>
        <div>
          <label className="label">Bedrooms</label>
          <input type="number" className="input" {...field("bedrooms")} />
        </div>
        <div>
          <label className="label">Nightly rate (pence)</label>
          <input type="number" className="input" {...field("nightlyRate")} />
        </div>
        <div>
          <label className="label">Cleaning fee (pence)</label>
          <input type="number" className="input" {...field("cleaningFee")} />
        </div>
      </div>
      <button className="btn-primary" disabled={saving}>{saving ? "Saving…" : "Save changes"}</button>
      {saved && <span className="ml-3 text-sage-600 text-sm">Saved.</span>}
    </form>
  );
}

export default function AdminProperty() {
  return (
    <div className="min-h-screen bg-shell-50">
      <div className="section py-10">
        <Link href="/admin" className="text-sm text-sage-500 hover:text-sage-800">← Admin</Link>
        <h1 className="text-2xl font-bold mt-2 mb-6">Listing details</h1>
        <AdminGate>{({ authHeader }) => <PropertyEditor authHeader={authHeader} />}</AdminGate>
      </div>
    </div>
  );
}
