import { useEffect, useState } from "react";
import Layout from "../components/Layout";
import Gallery, { GalleryImage } from "../components/Gallery";
import BookingWidget from "../components/BookingWidget";

type Property = {
  id: number;
  name: string;
  tagline?: string | null;
  description?: string | null;
  location?: string | null;
  sleeps: number;
  bedrooms: number;
  nightlyRate: number;
  cleaningFee: number;
  currency: string;
};

const AMENITIES = [
  "Private decking with sea views",
  "Fully equipped kitchen",
  "Free WiFi & smart TV",
  "Parking on site",
  "5 minute walk to the beach",
  "Pet friendly",
];

export default function Home() {
  const [property, setProperty] = useState<Property | null>(null);
  const [images, setImages] = useState<GalleryImage[]>([]);

  useEffect(() => {
    fetch("/api/property?propertyId=1").then((r) => r.json()).then((d: any) => d.property && setProperty(d.property));
    fetch("/api/gallery?propertyId=1").then((r) => r.json()).then((d: any) => setImages(d.images || []));
  }, []);

  return (
    <Layout propertyName={property?.name}>
      <section className="relative bg-sage-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_top_right,_theme(colors.sage.300),_transparent_60%)]" />
        <div className="section relative py-20 md:py-28">
          <span className="inline-block bg-accent-500 text-white text-xs font-semibold tracking-wide uppercase px-3 py-1 rounded-full mb-4">
            Now taking bookings
          </span>
          <h1 className="text-4xl md:text-5xl font-bold max-w-2xl leading-tight">
            {property?.name || "AJG Seaside Caravans"}
          </h1>
          <p className="mt-4 text-lg text-sage-100 max-w-xl">
            {property?.tagline || "Wake up to sea air and dune grass"}
          </p>
          <div className="mt-8 flex gap-3">
            <a href="#book" className="btn-accent">Check availability</a>
            <a href="#gallery" className="btn bg-white/10 text-white border border-white/30 hover:bg-white/20">
              View gallery
            </a>
          </div>
        </div>
      </section>

      <section id="about" className="section py-16 grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <h2 className="text-2xl font-bold mb-3">About this stay</h2>
          <p className="text-sage-700 leading-relaxed">
            {property?.description ||
              "A cosy caravan a short walk from the beach, with a private deck, full kitchen, and everything you need for a relaxed seaside break."}
          </p>
          {property?.location && <p className="mt-3 text-sm text-sage-500">📍 {property.location}</p>}
        </div>
        <div className="card p-6">
          <h3 className="font-semibold mb-3">At a glance</h3>
          <ul className="space-y-2 text-sm text-sage-700">
            <li>🛏️ Sleeps {property?.sleeps ?? 6}</li>
            <li>🚪 {property?.bedrooms ?? 3} bedrooms</li>
            {property && <li>💷 From {(property.nightlyRate / 100).toFixed(0)} {property.currency.toUpperCase()} / night</li>}
          </ul>
        </div>
      </section>

      <section className="bg-sage-50 py-16">
        <div className="section">
          <h2 className="text-2xl font-bold mb-6">Amenities</h2>
          <ul className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
            {AMENITIES.map((a) => (
              <li key={a} className="flex items-center gap-2 card p-3 text-sm">
                <span className="text-accent-600">●</span> {a}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section id="gallery" className="section py-16">
        <h2 className="text-2xl font-bold mb-6">Gallery</h2>
        <Gallery images={images} />
      </section>

      <section id="book" className="bg-sage-50 py-16">
        <div className="section">
          <h2 className="text-2xl font-bold mb-2">Check availability &amp; book</h2>
          <p className="text-sage-600 mb-6">Pick your dates below — payment is handled securely by Stripe.</p>
          <BookingWidget propertyId={1} />
        </div>
      </section>
    </Layout>
  );
}
