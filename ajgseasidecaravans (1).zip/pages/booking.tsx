import Layout from "../components/Layout";
import BookingWidget from "../components/BookingWidget";

export default function BookingPage() {
  return (
    <Layout>
      <div className="section py-16">
        <h1 className="text-3xl font-bold mb-2">Book your stay</h1>
        <p className="text-sage-600 mb-8">Pick your dates, enter your details, and pay securely by card.</p>
        <BookingWidget propertyId={1} />
      </div>
    </Layout>
  );
}
