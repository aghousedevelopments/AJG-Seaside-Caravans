import type { NextApiRequest, NextApiResponse } from "next";
import { getEnv } from "../../lib/env";
import { getPrisma } from "../../lib/prisma";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const env = getEnv();
  const prisma = getPrisma(env);
  const idParam = (req.query.propertyId as string) || "1";

  const property = await prisma.property.findUnique({ where: { id: Number(idParam) } });
  if (!property) return res.status(404).json({ error: "not found" });
  res.json({ property });
}
