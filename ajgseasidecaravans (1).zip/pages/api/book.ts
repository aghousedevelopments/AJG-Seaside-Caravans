import type { NextApiRequest, NextApiResponse } from "next";
import Stripe from "stripe";
import { getEnv } from "../../lib/env";
import { getPrisma } from "../../lib/prisma";
import { computeTotal, nightsBetween } from "../../lib/pricing";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).end();

  const env = getEnv();
  const prisma = getPrisma(env);
  const body = req.body;
  if (!body) return res.status(400).json({ error: "invalid body" });

  const { propertyId, startDate, endDate, guestName, guestEmail, guests } = body;
  if (!propertyId || !startDate || !endDate || !guestName || !guestEmail) {
    return res.status(400).json({ error: "missing fields" });
  }

  const s = new Date(startDate);
  const e = new Date(endDate);
  const nights = nightsBetween(s, e);
  if (!(nights > 0)) return res.status(400).json({ error: "invalid date range" });

  const property = await prisma.property.findUnique({ where: { id: Number(propertyId) } });
  if (!property) return res.status(404).json({ error: "property not found" });

  const holdCutoff = new Date(Date.now() - 20 * 60 * 1000);
  const conflict = await prisma.booking.findFirst({
    where: {
      propertyId: Number(propertyId),
      OR: [{ status: "CONFIRMED" }, { status: "PENDING", createdAt: { gt: holdCutoff } }],
      AND: [{ startDate: { lt: e } }, { endDate: { gt: s } }],
    },
  });
  if (conflict) return res.status(409).json({ error: "Those dates are no longer available" });

  if (!env.STRIPE_SECRET_KEY) {
    return res.status(500).json({ error: "Payments are not configured yet (missing STRIPE_SECRET_KEY)" });
  }
  const stripe = new Stripe(env.STRIPE_SECRET_KEY, { apiVersion: "2024-06-20" });

  // Total is always computed server-side from the property's rate — never
  // trust a client-supplied amount for a payment.
  const totalAmount = computeTotal(property.nightlyRate, property.cleaningFee, nights);
  const currency = property.currency;

  const booking = await prisma.booking.create({
    data: {
      propertyId: Number(propertyId),
      startDate: s,
      endDate: e,
      guestName,
      guestEmail,
      guests: Number(guests) || 2,
      totalAmount,
      currency,
      status: "PENDING",
    },
  });

  const siteUrl = env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    payment_method_types: ["card"],
    line_items: [
      {
        price_data: {
          currency,
          product_data: {
            name: `${property.name} — ${nights} night${nights === 1 ? "" : "s"}`,
            description: `${s.toDateString()} to ${e.toDateString()}`,
          },
          unit_amount: totalAmount,
        },
        quantity: 1,
      },
    ],
    customer_email: guestEmail,
    success_url: `${siteUrl}/booking/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${siteUrl}/booking/cancel`,
    metadata: { bookingId: String(booking.id) },
  });

  await prisma.booking.update({ where: { id: booking.id }, data: { stripeSessionId: session.id } });

  res.json({ url: session.url });
}
