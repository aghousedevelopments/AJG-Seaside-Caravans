import type { NextApiRequest, NextApiResponse } from "next";
import { getEnv } from "../../lib/env";
import { getPrisma } from "../../lib/prisma";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const env = getEnv();
  const prisma = getPrisma(env);
  const propertyId = Number((req.query.propertyId as string) || "1");

  const images = await prisma.image.findMany({
    where: { propertyId },
    orderBy: { order: "asc" },
    select: { id: true, url: true, alt: true, order: true },
  });
  res.json({ images });
}
