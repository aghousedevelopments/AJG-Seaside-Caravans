import type { NextApiRequest, NextApiResponse } from "next";
import { getEnv } from "../../lib/env";
import { getPrisma } from "../../lib/prisma";
import { buildIcs } from "../../lib/ical";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const env = getEnv();
  const prisma = getPrisma(env);
  const propertyId = req.query.propertyId as string | undefined;
  if (!propertyId) return res.status(400).send("missing propertyId");

  const bookings = await prisma.booking.findMany({ where: { propertyId: Number(propertyId), status: "CONFIRMED" } });
  const domain = (env.NEXT_PUBLIC_SITE_URL || "localhost").replace(/^https?:\/\//, "");
  const ics = buildIcs(
    domain,
    bookings.map((b) => ({
      id: b.id,
      start: new Date(b.startDate),
      end: new Date(b.endDate),
      summary: `Booked: ${b.guestName}`,
      description: `Booking ${b.id}`,
    }))
  );

  res.setHeader("Content-Type", "text/calendar; charset=utf-8");
  res.send(ics);
}
