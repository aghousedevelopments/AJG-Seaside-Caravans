import type { NextApiRequest, NextApiResponse } from "next";
import { getEnv } from "../../../lib/env";
import { getPrisma } from "../../../lib/prisma";
import { checkAdminAuth, sendUnauthorized } from "../../../lib/adminAuth";

const EDITABLE_FIELDS = ["name", "tagline", "description", "location", "sleeps", "bedrooms", "nightlyRate", "cleaningFee", "currency"] as const;

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const env = getEnv();
  if (!checkAdminAuth(req, env.ADMIN_PASSWORD)) return sendUnauthorized(res);
  const prisma = getPrisma(env);

  if (req.method === "GET") {
    const propertyId = Number((req.query.propertyId as string) || "1");
    const property = await prisma.property.findUnique({ where: { id: propertyId } });
    return res.json({ property });
  }

  if (req.method === "POST") {
    const body = req.body;
    const propertyId = Number(body.propertyId || 1);
    const data: Record<string, any> = {};
    for (const field of EDITABLE_FIELDS) {
      if (body[field] === undefined) continue;
      data[field] = ["sleeps", "bedrooms", "nightlyRate", "cleaningFee"].includes(field) ? Number(body[field]) : body[field];
    }
    const property = await prisma.property.update({ where: { id: propertyId }, data });
    return res.json({ property });
  }

  return res.status(405).end();
}
