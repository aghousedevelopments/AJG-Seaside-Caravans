import type { NextApiRequest, NextApiResponse } from "next";
import { getEnv } from "../../../lib/env";
import { getPrisma } from "../../../lib/prisma";
import { checkAdminAuth, sendUnauthorized } from "../../../lib/adminAuth";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const env = getEnv();
  if (!checkAdminAuth(req, env.ADMIN_PASSWORD)) return sendUnauthorized(res);

  const prisma = getPrisma(env);
  const bookings = await prisma.booking.findMany({ include: { property: true }, orderBy: { createdAt: "desc" } });
  res.json({ bookings });
}
