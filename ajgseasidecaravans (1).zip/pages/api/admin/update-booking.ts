import type { NextApiRequest, NextApiResponse } from "next";
import { getEnv } from "../../../lib/env";
import { getPrisma } from "../../../lib/prisma";
import { checkAdminAuth, sendUnauthorized } from "../../../lib/adminAuth";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const env = getEnv();
  if (!checkAdminAuth(req, env.ADMIN_PASSWORD)) return sendUnauthorized(res);
  if (req.method !== "POST") return res.status(405).end();

  const prisma = getPrisma(env);
  const { id, status } = req.body;
  if (!id || !status) return res.status(400).json({ error: "missing" });
  const allowed = ["PENDING", "CONFIRMED", "CANCELLED"];
  if (!allowed.includes(status)) return res.status(400).json({ error: "invalid status" });

  const updated = await prisma.booking.update({ where: { id: Number(id) }, data: { status } });
  res.json({ booking: updated });
}
