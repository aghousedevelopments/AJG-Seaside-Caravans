import type { NextApiRequest, NextApiResponse } from "next";
import { getEnv } from "../../../lib/env";
import { getPrisma } from "../../../lib/prisma";
import { checkAdminAuth, sendUnauthorized } from "../../../lib/adminAuth";

// Body: { order: [imageId, imageId, ...] } in the desired display order.
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const env = getEnv();
  if (!checkAdminAuth(req, env.ADMIN_PASSWORD)) return sendUnauthorized(res);
  if (req.method !== "POST") return res.status(405).end();

  const prisma = getPrisma(env);
  const { order } = req.body;
  if (!Array.isArray(order)) return res.status(400).json({ error: "missing order" });

  await Promise.all(order.map((id: number, index: number) => prisma.image.update({ where: { id }, data: { order: index } })));

  res.json({ ok: true });
}
