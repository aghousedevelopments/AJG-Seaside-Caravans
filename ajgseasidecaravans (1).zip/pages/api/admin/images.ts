import type { NextApiRequest, NextApiResponse } from "next";
import { getEnv } from "../../../lib/env";
import { getPrisma } from "../../../lib/prisma";
import { checkAdminAuth, sendUnauthorized } from "../../../lib/adminAuth";
import { saveImage } from "../../../lib/imageStorage";

// Photos arrive as base64 data URLs, well over Next's 1mb JSON default.
export const config = { api: { bodyParser: { sizeLimit: "15mb" } } };

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const env = getEnv();
  if (!checkAdminAuth(req, env.ADMIN_PASSWORD)) return sendUnauthorized(res);
  const prisma = getPrisma(env);

  if (req.method === "GET") {
    const propertyId = Number((req.query.propertyId as string) || "1");
    const images = await prisma.image.findMany({ where: { propertyId }, orderBy: { order: "asc" } });
    return res.json({ images });
  }

  if (req.method === "POST") {
    try {
      const { propertyId, filename, dataUrl, alt, order } = req.body;
      if (!propertyId || !filename || !dataUrl) return res.status(400).json({ error: "missing" });
      const { url, key } = await saveImage(env, { dataUrl, filename });
      const img = await prisma.image.create({
        data: { propertyId: Number(propertyId), url, key, alt: alt || null, order: Number(order) || 0 },
      });
      return res.json({ image: img });
    } catch (err: any) {
      console.error("upload error", err);
      return res.status(500).json({ error: err.message || "upload failed" });
    }
  }

  return res.status(405).end();
}
