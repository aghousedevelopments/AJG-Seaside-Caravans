import type { NextApiRequest, NextApiResponse } from "next";
import { getEnv } from "../../../lib/env";
import { getPrisma } from "../../../lib/prisma";
import { checkAdminAuth, sendUnauthorized } from "../../../lib/adminAuth";
import { deleteImage } from "../../../lib/imageStorage";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const env = getEnv();
  if (!checkAdminAuth(req, env.ADMIN_PASSWORD)) return sendUnauthorized(res);
  if (req.method !== "POST") return res.status(405).end();

  const prisma = getPrisma(env);
  const { id } = req.body;
  if (!id) return res.status(400).json({ error: "missing id" });

  const img = await prisma.image.findUnique({ where: { id: Number(id) } });
  if (!img) return res.status(404).json({ error: "not found" });

  await deleteImage(env, img.key);
  await prisma.image.delete({ where: { id: Number(id) } });
  res.json({ ok: true });
}
