import type { NextApiRequest, NextApiResponse } from "next";
import { getEnv } from "../../lib/env";
import { getPrisma } from "../../lib/prisma";

// Returns booked date ranges so the calendar can disable them, and optionally
// a yes/no check for a specific start/end range via ?start=&end=.
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const env = getEnv();
  const prisma = getPrisma(env);
  const propertyId = Number((req.query.propertyId as string) || "1");
  const start = req.query.start as string | undefined;
  const end = req.query.end as string | undefined;

  // Held statuses: CONFIRMED bookings, plus PENDING ones created in the last
  // 20 minutes (mid-checkout) so two guests can't pay for the same dates.
  const holdCutoff = new Date(Date.now() - 20 * 60 * 1000);
  const held = await prisma.booking.findMany({
    where: {
      propertyId,
      OR: [{ status: "CONFIRMED" }, { status: "PENDING", createdAt: { gt: holdCutoff } }],
    },
    select: { startDate: true, endDate: true },
  });

  if (start && end) {
    const s = new Date(start);
    const e = new Date(end);
    const conflict = held.some((b) => b.startDate < e && b.endDate > s);
    return res.json({ available: !conflict });
  }

  res.json({ ranges: held.map((b) => ({ start: b.startDate, end: b.endDate })) });
}
