import type { NextApiRequest, NextApiResponse } from "next";
import Stripe from "stripe";
import { getEnv } from "../../lib/env";
import { getPrisma } from "../../lib/prisma";
import sendEmail from "../../lib/sendEmail";

export const config = { api: { bodyParser: false } };

function readRawBody(req: NextApiRequest): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    req.on("data", (chunk) => chunks.push(chunk));
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const env = getEnv();
  const sig = (req.headers["stripe-signature"] as string) || "";
  const rawBody = await readRawBody(req);

  if (!env.STRIPE_SECRET_KEY || !env.STRIPE_WEBHOOK_SECRET) {
    return res.status(500).send("Webhooks not configured");
  }

  const stripe = new Stripe(env.STRIPE_SECRET_KEY, { apiVersion: "2024-06-20" });

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, sig, env.STRIPE_WEBHOOK_SECRET);
  } catch (err: any) {
    console.error("Webhook signature error", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const bookingId = session.metadata?.bookingId;
    if (bookingId) {
      const prisma = getPrisma(env);
      const bookingIdNum = Number(bookingId);
      await prisma.booking.update({ where: { id: bookingIdNum }, data: { status: "CONFIRMED" } });
      const booking = await prisma.booking.findUnique({ where: { id: bookingIdNum }, include: { property: true } });
      if (booking) {
        try {
          await sendEmail(env, {
            to: booking.guestEmail,
            subject: `Booking confirmed — ${booking.property?.name ?? "Property"}`,
            text: `Hi ${booking.guestName},\n\nYour booking (${booking.id}) for ${new Date(
              booking.startDate
            ).toDateString()} to ${new Date(booking.endDate).toDateString()} has been confirmed.\n\nThank you.`,
            html: `<p>Hi ${booking.guestName},</p><p>Your booking (${booking.id}) for <strong>${
              booking.property?.name ?? "the property"
            }</strong> from <strong>${new Date(booking.startDate).toDateString()}</strong> to <strong>${new Date(
              booking.endDate
            ).toDateString()}</strong> has been confirmed.</p><p>Thanks.</p>`,
          });
        } catch (err) {
          console.error("Error sending confirmation email", err);
        }
      }
    }
  }

  res.json({ received: true });
}
