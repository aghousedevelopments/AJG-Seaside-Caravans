import type { NextApiRequest, NextApiResponse } from "next";
import { getEnv } from "../../lib/env";
import { getPrisma } from "../../lib/prisma";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const env = getEnv();
  const prisma = getPrisma(env);
  const sessionId = req.query.session_id as string | undefined;
  if (!sessionId) return res.status(400).json({ booking: null });

  const booking = await prisma.booking.findUnique({ where: { stripeSessionId: sessionId } });
  res.json({ booking });
}
