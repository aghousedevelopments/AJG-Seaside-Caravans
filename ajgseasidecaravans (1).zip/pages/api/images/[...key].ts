import type { NextApiRequest, NextApiResponse } from "next";
import { getEnv } from "../../../lib/env";

// Serves a gallery image straight out of R2, e.g. /api/images/gallery/123-abc.jpg
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const env = getEnv();
  const parts = req.query.key;
  const key = Array.isArray(parts) ? parts.join("/") : parts;
  if (!key) return res.status(404).end("Not found");

  const object = await env.GALLERY_BUCKET.get(key);
  if (!object) return res.status(404).end("Not found");

  const buf = Buffer.from(await object.arrayBuffer());
  res.setHeader("Content-Type", object.httpMetadata?.contentType || "application/octet-stream");
  res.setHeader("ETag", object.httpEtag);
  res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
  res.status(200).send(buf);
}
